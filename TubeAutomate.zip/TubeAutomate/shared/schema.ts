import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, json, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  status: text("status").notNull().default("script_upload"), // workflow step
  currentStep: integer("current_step").notNull().default(1),
  totalSteps: integer("total_steps").notNull().default(7),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

export const scripts = pgTable("scripts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  fileName: text("file_name").notNull(),
  originalContent: text("original_content").notNull(),
  improvedContent: text("improved_content"),
  analysis: json("analysis").$type<{
    grammar: { status: string; message: string };
    engagement: { status: string; message: string; suggestions: string[] };
    pacing: { status: string; message: string; suggestions: string[] };
  }>(),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const mediaFiles = pgTable("media_files", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  type: text("type").notNull(), // 'face_video', 'tv_episode', 'audio', 'thumbnail'
  fileName: text("file_name").notNull(),
  filePath: text("file_path").notNull(),
  fileSize: integer("file_size").notNull(),
  mimeType: text("mime_type").notNull(),
  status: text("status").notNull().default("uploaded"), // 'uploaded', 'processing', 'processed', 'error'
  metadata: json("metadata"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const audioProcessing = pgTable("audio_processing", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  voiceType: text("voice_type").notNull(), // 'professional_male', 'conversational_female', 'narrative_male'
  status: text("status").notNull().default("pending"), // 'pending', 'generating', 'enhancing', 'completed', 'error'
  generatedAudioPath: text("generated_audio_path"),
  enhancedAudioPath: text("enhanced_audio_path"),
  duration: integer("duration"), // in seconds
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const contentMetadata = pgTable("content_metadata", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  tags: json("tags").$type<string[]>(),
  thumbnailPrompt: text("thumbnail_prompt"),
  selectedThumbnailPath: text("selected_thumbnail_path"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertScriptSchema = createInsertSchema(scripts).omit({
  id: true,
  createdAt: true,
});

export const insertMediaFileSchema = createInsertSchema(mediaFiles).omit({
  id: true,
  createdAt: true,
});

export const insertAudioProcessingSchema = createInsertSchema(audioProcessing).omit({
  id: true,
  createdAt: true,
});

export const insertContentMetadataSchema = createInsertSchema(contentMetadata).omit({
  id: true,
  createdAt: true,
});

export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Script = typeof scripts.$inferSelect;
export type InsertScript = z.infer<typeof insertScriptSchema>;
export type MediaFile = typeof mediaFiles.$inferSelect;
export type InsertMediaFile = z.infer<typeof insertMediaFileSchema>;
export type AudioProcessing = typeof audioProcessing.$inferSelect;
export type InsertAudioProcessing = z.infer<typeof insertAudioProcessingSchema>;
export type ContentMetadata = typeof contentMetadata.$inferSelect;
export type InsertContentMetadata = z.infer<typeof insertContentMetadataSchema>;
