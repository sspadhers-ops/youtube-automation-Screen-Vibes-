import { useState, useCallback } from "react";

interface UseFileUploadOptions {
  acceptedTypes?: string[];
  maxSizeMB?: number;
  onSuccess?: (file: File) => void;
  onError?: (error: string) => void;
}

interface FileUploadState {
  file: File | null;
  uploading: boolean;
  progress: number;
  error: string | null;
}

export function useFileUpload({
  acceptedTypes = [],
  maxSizeMB = 10,
  onSuccess,
  onError,
}: UseFileUploadOptions = {}) {
  const [state, setState] = useState<FileUploadState>({
    file: null,
    uploading: false,
    progress: 0,
    error: null,
  });

  const validateFile = useCallback((file: File): string | null => {
    // Check file size
    const maxSizeBytes = maxSizeMB * 1024 * 1024;
    if (file.size > maxSizeBytes) {
      return `File size must be less than ${maxSizeMB}MB`;
    }

    // Check file type
    if (acceptedTypes.length > 0) {
      const fileExtension = `.${file.name.split('.').pop()?.toLowerCase()}`;
      const isAccepted = acceptedTypes.some(type => 
        file.type.includes(type) || fileExtension === type
      );
      
      if (!isAccepted) {
        return `File type not supported. Accepted types: ${acceptedTypes.join(', ')}`;
      }
    }

    return null;
  }, [acceptedTypes, maxSizeMB]);

  const uploadFile = useCallback(async (file: File, uploadUrl: string, additionalData?: Record<string, string>) => {
    const validationError = validateFile(file);
    if (validationError) {
      setState(prev => ({ ...prev, error: validationError }));
      onError?.(validationError);
      return null;
    }

    setState(prev => ({ 
      ...prev, 
      file, 
      uploading: true, 
      progress: 0, 
      error: null 
    }));

    try {
      const formData = new FormData();
      formData.append("file", file);
      
      // Add additional form data
      if (additionalData) {
        Object.entries(additionalData).forEach(([key, value]) => {
          formData.append(key, value);
        });
      }

      // Create XMLHttpRequest for progress tracking
      const xhr = new XMLHttpRequest();
      
      return new Promise((resolve, reject) => {
        xhr.upload.addEventListener("progress", (event) => {
          if (event.lengthComputable) {
            const progress = Math.round((event.loaded / event.total) * 100);
            setState(prev => ({ ...prev, progress }));
          }
        });

        xhr.addEventListener("load", () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            setState(prev => ({ 
              ...prev, 
              uploading: false, 
              progress: 100 
            }));
            onSuccess?.(file);
            resolve(JSON.parse(xhr.responseText));
          } else {
            const error = xhr.responseText || "Upload failed";
            setState(prev => ({ 
              ...prev, 
              uploading: false, 
              error 
            }));
            onError?.(error);
            reject(new Error(error));
          }
        });

        xhr.addEventListener("error", () => {
          const error = "Network error during upload";
          setState(prev => ({ 
            ...prev, 
            uploading: false, 
            error 
          }));
          onError?.(error);
          reject(new Error(error));
        });

        xhr.open("POST", uploadUrl);
        xhr.send(formData);
      });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Upload failed";
      setState(prev => ({ 
        ...prev, 
        uploading: false, 
        error: errorMessage 
      }));
      onError?.(errorMessage);
      return null;
    }
  }, [validateFile, onSuccess, onError]);

  const resetUpload = useCallback(() => {
    setState({
      file: null,
      uploading: false,
      progress: 0,
      error: null,
    });
  }, []);

  return {
    ...state,
    uploadFile,
    resetUpload,
    validateFile,
  };
}
