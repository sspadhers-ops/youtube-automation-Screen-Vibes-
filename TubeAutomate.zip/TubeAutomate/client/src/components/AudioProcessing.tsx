import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface AudioProcessingProps {
  projectId: string;
  audioProcessing?: any;
  script?: any;
}

const VOICE_OPTIONS = [
  {
    id: "professional_male",
    name: "Professional Male",
    description: "English • Clear • Confident",
    icon: "fas fa-user",
    color: "blue",
  },
  {
    id: "conversational_female",
    name: "Conversational Female",
    description: "English • Warm • Engaging",
    icon: "fas fa-user",
    color: "green",
  },
  {
    id: "narrative_male",
    name: "Narrative Male",
    description: "English • Deep • Authoritative",
    icon: "fas fa-user",
    color: "purple",
  },
];

export default function AudioProcessing({ projectId, audioProcessing, script }: AudioProcessingProps) {
  const [selectedVoice, setSelectedVoice] = useState<string>(audioProcessing?.voiceType || "conversational_female");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createAudioMutation = useMutation({
    mutationFn: async (voiceType: string) => {
      const response = await apiRequest("POST", `/api/projects/${projectId}/audio`, {
        voiceType,
        status: "pending",
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "complete"] });
      toast({
        title: "Audio Processing Started",
        description: "Voiceover generation has been initiated and will be processed shortly.",
      });
    },
    onError: (error) => {
      toast({
        title: "Processing Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleVoiceSelect = (voiceId: string) => {
    setSelectedVoice(voiceId);
  };

  const handleGenerateVoiceover = () => {
    if (!script) {
      toast({
        title: "No Script Available",
        description: "Please upload a script before generating voiceover.",
        variant: "destructive",
      });
      return;
    }
    createAudioMutation.mutate(selectedVoice);
  };

  const getProcessingSteps = () => [
    {
      id: 1,
      title: "Voice Generation",
      description: "Google Studio",
      completed: audioProcessing?.status === "generating" || audioProcessing?.status === "enhancing" || audioProcessing?.status === "completed",
      active: audioProcessing?.status === "generating",
    },
    {
      id: 2,
      title: "Audio Enhancement",
      description: "Adobe Enhance",
      completed: audioProcessing?.status === "enhancing" || audioProcessing?.status === "completed",
      active: audioProcessing?.status === "enhancing",
    },
    {
      id: 3,
      title: "Quality Check",
      description: "AI Analysis",
      completed: audioProcessing?.status === "completed",
      active: false,
    },
  ];

  const processingSteps = getProcessingSteps();

  return (
    <div className="bg-card rounded-xl shadow-sm border border-border p-8">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-foreground mb-2">Audio Processing Pipeline</h2>
        <p className="text-muted-foreground">Voice generation and enhancement workflow</p>
      </div>

      <div className="space-y-6">
        {/* Voice Selection */}
        <div>
          <h3 className="font-medium text-foreground mb-4">Select Voice Type</h3>
          <div className="grid md:grid-cols-3 gap-4">
            {VOICE_OPTIONS.map((voice) => {
              const isSelected = selectedVoice === voice.id;
              return (
                <div
                  key={voice.id}
                  className={`p-4 border rounded-lg cursor-pointer transition-all ${
                    isSelected
                      ? "border-primary bg-primary/5 border-2"
                      : "border-border hover:border-primary hover:bg-primary/5"
                  }`}
                  onClick={() => handleVoiceSelect(voice.id)}
                  data-testid={`button-voice-${voice.id}`}
                >
                  <div className="flex items-center space-x-3 mb-3">
                    <div className={`w-10 h-10 bg-${voice.color}-100 rounded-full flex items-center justify-center`}>
                      <i className={`${voice.icon} text-${voice.color}-600`}></i>
                    </div>
                    <div>
                      <h4 className="font-medium text-foreground">{voice.name}</h4>
                      <p className="text-xs text-muted-foreground">{voice.description}</p>
                    </div>
                  </div>
                  <button 
                    className={`w-full py-2 px-3 rounded text-sm transition-colors ${
                      isSelected 
                        ? "bg-primary text-primary-foreground" 
                        : "bg-muted hover:bg-muted/80"
                    }`}
                    onClick={(e) => {
                      e.stopPropagation();
                      // TODO: Implement voice preview
                    }}
                    data-testid={`button-preview-${voice.id}`}
                  >
                    <i className={`${isSelected ? "fas fa-check" : "fas fa-play"} mr-2`}></i>
                    {isSelected ? "Selected" : "Preview"}
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Audio Processing Status */}
        <div className="bg-muted/30 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-medium text-foreground">Processing Pipeline</h4>
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full ${
                audioProcessing?.status === "pending" || audioProcessing?.status === "generating" || audioProcessing?.status === "enhancing"
                  ? "bg-primary animate-pulse"
                  : audioProcessing?.status === "completed"
                    ? "bg-accent"
                    : "bg-muted-foreground"
              }`}></div>
              <span className={`text-sm font-medium ${
                audioProcessing?.status === "completed" ? "text-accent" : "text-primary"
              }`} data-testid="text-audio-status">
                {audioProcessing?.status ? audioProcessing.status.charAt(0).toUpperCase() + audioProcessing.status.slice(1) : "Ready"}
              </span>
            </div>
          </div>

          <div className="space-y-3">
            {processingSteps.map((step) => (
              <div key={step.id} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                    step.completed
                      ? "bg-accent"
                      : step.active
                        ? "bg-primary"
                        : "bg-border"
                  }`}>
                    {step.completed ? (
                      <i className="fas fa-check text-white text-xs"></i>
                    ) : step.active ? (
                      <i className="fas fa-spinner fa-spin text-white text-xs"></i>
                    ) : (
                      <span className="text-xs text-muted-foreground">{step.id}</span>
                    )}
                  </div>
                  <span className={`text-sm font-medium ${
                    step.completed || step.active ? "text-foreground" : "text-muted-foreground"
                  }`}>
                    {step.title}
                  </span>
                </div>
                <span className="text-xs text-muted-foreground">{step.description}</span>
              </div>
            ))}
          </div>

          <button
            onClick={handleGenerateVoiceover}
            disabled={createAudioMutation.isPending || !script || audioProcessing?.status === "generating" || audioProcessing?.status === "enhancing"}
            className="w-full mt-6 bg-primary hover:bg-primary/90 text-primary-foreground py-3 px-4 rounded-md font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            data-testid="button-generate-voiceover"
          >
            {createAudioMutation.isPending ? (
              <>
                <i className="fas fa-spinner fa-spin mr-2"></i>
                Starting Generation...
              </>
            ) : audioProcessing?.status === "generating" || audioProcessing?.status === "enhancing" ? (
              <>
                <i className="fas fa-clock mr-2"></i>
                Processing in Progress
              </>
            ) : audioProcessing?.status === "completed" ? (
              <>
                <i className="fas fa-check mr-2"></i>
                Voiceover Complete
              </>
            ) : (
              <>
                <i className="fas fa-microphone mr-2"></i>
                Generate Voiceover
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
