import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface AIAnalysisProps {
  script: any;
  projectId: string;
}

export default function AIAnalysis({ script, projectId }: AIAnalysisProps) {
  const [showImproved, setShowImproved] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const analyzeMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/scripts/${script.id}/analyze`, { projectId });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "complete"] });
      toast({
        title: "Analysis Complete",
        description: "Your script has been analyzed and improvements have been suggested.",
      });
    },
    onError: (error) => {
      toast({
        title: "Analysis Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const downloadScript = (content: string, filename: string) => {
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const analysis = script.analysis;
  const hasAnalysis = analysis && !analyzeMutation.isPending;

  return (
    <div className="bg-card rounded-xl shadow-sm border border-border p-8">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-foreground mb-2">AI Script Analysis</h2>
        <p className="text-muted-foreground">AI-powered analysis and improvement suggestions</p>
      </div>

      {!hasAnalysis ? (
        <div className="text-center py-8">
          {analyzeMutation.isPending ? (
            <div className="space-y-4">
              <i className="fas fa-spinner fa-spin text-3xl text-primary"></i>
              <p className="text-foreground font-medium">Analyzing your script...</p>
              <p className="text-sm text-muted-foreground">This may take a few moments</p>
            </div>
          ) : (
            <div className="space-y-4">
              <i className="fas fa-brain text-3xl text-muted-foreground"></i>
              <p className="text-foreground font-medium">Ready to analyze your script</p>
              <button
                onClick={() => analyzeMutation.mutate()}
                className="bg-primary hover:bg-primary/90 text-primary-foreground px-6 py-2 rounded-md font-medium transition-colors"
                data-testid="button-analyze-script"
              >
                <i className="fas fa-magic mr-2"></i>Analyze Script
              </button>
            </div>
          )}
        </div>
      ) : (
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Original/Improved Script */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium text-foreground">
                {showImproved ? "Improved Script" : "Original Script"}
              </h3>
              {script.improvedContent && (
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setShowImproved(!showImproved)}
                    className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
                      showImproved
                        ? "bg-accent text-accent-foreground"
                        : "bg-muted text-muted-foreground hover:bg-muted/80"
                    }`}
                    data-testid="button-toggle-script-view"
                  >
                    {showImproved ? "Show Original" : "Show Improved"}
                  </button>
                </div>
              )}
            </div>
            <div className="bg-muted/30 rounded-lg p-6 h-80 overflow-y-auto">
              <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap" data-testid="text-script-content">
                {showImproved && script.improvedContent ? script.improvedContent : script.originalContent}
              </p>
            </div>
          </div>

          {/* AI Suggestions */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-foreground">AI Improvements</h3>
            <div className="space-y-4">
              {/* Grammar Check */}
              {analysis.grammar && (
                <div className={`border rounded-lg p-4 ${
                  analysis.grammar.status === "good" 
                    ? "bg-green-50 border-green-200" 
                    : "bg-orange-50 border-orange-200"
                }`}>
                  <div className="flex items-start space-x-3">
                    <div className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center ${
                      analysis.grammar.status === "good" 
                        ? "bg-green-100" 
                        : "bg-orange-100"
                    }`}>
                      <i className={`text-xs ${
                        analysis.grammar.status === "good" 
                          ? "fas fa-check text-green-600" 
                          : "fas fa-exclamation text-orange-600"
                      }`}></i>
                    </div>
                    <div>
                      <h4 className={`font-medium ${
                        analysis.grammar.status === "good" 
                          ? "text-green-800" 
                          : "text-orange-800"
                      }`}>
                        Grammar & Style
                      </h4>
                      <p className={`text-sm mt-1 ${
                        analysis.grammar.status === "good" 
                          ? "text-green-700" 
                          : "text-orange-700"
                      }`} data-testid="text-grammar-feedback">
                        {analysis.grammar.message}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Engagement Suggestions */}
              {analysis.engagement && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center">
                      <i className="fas fa-lightbulb text-blue-600 text-xs"></i>
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-blue-800">Engagement</h4>
                      <p className="text-sm text-blue-700 mt-1" data-testid="text-engagement-feedback">
                        {analysis.engagement.message}
                      </p>
                      {analysis.engagement.suggestions && analysis.engagement.suggestions.length > 0 && (
                        <ul className="text-sm text-blue-700 mt-2 space-y-1">
                          {analysis.engagement.suggestions.map((suggestion: string, index: number) => (
                            <li key={index} className="flex items-start">
                              <span className="mr-2">•</span>
                              <span>{suggestion}</span>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Pacing Suggestions */}
              {analysis.pacing && (
                <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center">
                      <i className="fas fa-clock text-orange-600 text-xs"></i>
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-orange-800">Pacing</h4>
                      <p className="text-sm text-orange-700 mt-1" data-testid="text-pacing-feedback">
                        {analysis.pacing.message}
                      </p>
                      {analysis.pacing.suggestions && analysis.pacing.suggestions.length > 0 && (
                        <ul className="text-sm text-orange-700 mt-2 space-y-1">
                          {analysis.pacing.suggestions.map((suggestion: string, index: number) => (
                            <li key={index} className="flex items-start">
                              <span className="mr-2">•</span>
                              <span>{suggestion}</span>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex space-x-3 pt-4">
                {script.improvedContent && (
                  <button
                    onClick={() => downloadScript(script.improvedContent, `improved-${script.fileName}`)}
                    className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground px-4 py-2 rounded-md font-medium transition-colors"
                    data-testid="button-download-improved"
                  >
                    <i className="fas fa-download mr-2"></i>Download Improved
                  </button>
                )}
                <button
                  onClick={() => downloadScript(script.originalContent, script.fileName)}
                  className="px-4 py-2 border border-border rounded-md font-medium text-foreground hover:bg-muted/50 transition-colors"
                  data-testid="button-download-original"
                >
                  <i className="fas fa-download mr-2"></i>Download Original
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
