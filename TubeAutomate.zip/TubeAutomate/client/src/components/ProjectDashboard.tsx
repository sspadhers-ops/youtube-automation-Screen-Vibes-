import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ProjectDashboardProps {
  project?: any;
  script?: any;
  mediaFiles: any[];
  audioProcessing?: any;
  metadata?: any;
  projectId: string;
}

interface AssetCardProps {
  icon: string;
  iconColor: string;
  title: string;
  status: string;
  description: string;
  isCompleted: boolean;
}

function AssetCard({ icon, iconColor, title, status, description, isCompleted }: AssetCardProps) {
  return (
    <div className={`p-4 border border-border rounded-lg ${!isCompleted ? 'opacity-50' : ''}`}>
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center space-x-3">
          <div className={`w-10 h-10 ${iconColor} rounded-lg flex items-center justify-center`}>
            <i className={`${icon} ${iconColor.includes('blue') ? 'text-blue-600' : iconColor.includes('purple') ? 'text-purple-600' : iconColor.includes('green') ? 'text-green-600' : 'text-orange-600'}`}></i>
          </div>
          <div>
            <h4 className="font-medium text-foreground">{title}</h4>
            <p className="text-xs text-muted-foreground">{status}</p>
          </div>
        </div>
        <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
          isCompleted ? 'bg-accent' : 'bg-border'
        }`}>
          <i className={`text-xs ${
            isCompleted ? 'fas fa-check text-white' : 'fas fa-clock text-muted-foreground'
          }`}></i>
        </div>
      </div>
      <div className="text-xs text-muted-foreground">
        {description}
      </div>
    </div>
  );
}

export default function ProjectDashboard({ project, script, mediaFiles, audioProcessing, metadata, projectId }: ProjectDashboardProps) {
  const [formData, setFormData] = useState({
    title: metadata?.title || "",
    description: metadata?.description || "",
    tags: metadata?.tags || [],
    newTag: "",
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updateMetadataMutation = useMutation({
    mutationFn: async (data: any) => {
      if (!metadata) {
        const response = await apiRequest("POST", `/api/projects/${projectId}/metadata`, data);
        return response.json();
      } else {
        const response = await apiRequest("PATCH", `/api/projects/${projectId}/metadata`, data);
        return response.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "complete"] });
      toast({
        title: "Metadata Updated",
        description: "Content metadata has been saved successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const generateMetadataMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/projects/${projectId}/generate-metadata`);
      return response.json();
    },
    onSuccess: (data) => {
      setFormData(prev => ({
        ...prev,
        title: data.title || prev.title,
        description: data.description || prev.description,
        tags: [...(prev.tags || []), ...(data.tags || [])],
      }));
      toast({
        title: "Metadata Generated",
        description: "AI has generated optimized metadata for your video.",
      });
    },
    onError: (error) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleAddTag = () => {
    if (formData.newTag.trim() && !formData.tags.includes(formData.newTag.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, prev.newTag.trim()],
        newTag: "",
      }));
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter((tag: string) => tag !== tagToRemove),
    }));
  };

  const handleSaveMetadata = () => {
    updateMetadataMutation.mutate({
      title: formData.title,
      description: formData.description,
      tags: formData.tags,
    });
  };

  const assets = [
    {
      icon: "fas fa-file-text",
      iconColor: "bg-blue-100",
      title: "Script",
      status: script ? script.fileName : "Pending upload",
      description: script ? `${script.originalContent?.length || 0} characters • Last modified ${new Date(script.createdAt).toLocaleDateString()}` : "Upload script file to continue",
      isCompleted: !!script,
    },
    {
      icon: "fas fa-microphone",
      iconColor: "bg-purple-100",
      title: "Audio",
      status: audioProcessing?.status === "completed" ? "Generated" : "Pending generation",
      description: audioProcessing?.status === "completed" 
        ? `${audioProcessing.duration || 0}s duration • Enhanced`
        : `Estimated: 3.2 MB • ~4 min duration`,
      isCompleted: audioProcessing?.status === "completed",
    },
    {
      icon: "fas fa-video",
      iconColor: "bg-green-100",
      title: "Video",
      status: mediaFiles.some(f => f.type === "face_video") ? "Uploaded" : "Pending upload",
      description: mediaFiles.some(f => f.type === "face_video") 
        ? `${Math.round(mediaFiles.find(f => f.type === "face_video")?.fileSize / 1024 / 1024 || 0)} MB`
        : "1080p • MP4 format preferred",
      isCompleted: mediaFiles.some(f => f.type === "face_video"),
    },
    {
      icon: "fas fa-image",
      iconColor: "bg-orange-100",
      title: "Thumbnail",
      status: "AI-generated",
      description: "1280x720 • JPEG format",
      isCompleted: false,
    },
  ];

  const progressPercentage = project ? Math.round((project.currentStep / project.totalSteps) * 100) : 0;

  return (
    <div className="bg-card rounded-xl shadow-sm border border-border p-8">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-foreground mb-2">Project Dashboard</h2>
        <p className="text-muted-foreground">Track all your content components and metadata</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Project Files */}
        <div className="lg:col-span-2 space-y-6">
          {/* Content Assets */}
          <div>
            <h3 className="font-medium text-foreground mb-3">Content Assets</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              {assets.map((asset, index) => (
                <AssetCard key={index} {...asset} />
              ))}
            </div>
          </div>

          {/* Content Metadata */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-foreground">Content Metadata</h3>
              {script && (
                <button
                  onClick={() => generateMetadataMutation.mutate()}
                  disabled={generateMetadataMutation.isPending}
                  className="px-3 py-1 text-sm bg-primary text-primary-foreground rounded hover:bg-primary/90 transition-colors disabled:opacity-50"
                  data-testid="button-generate-metadata"
                >
                  {generateMetadataMutation.isPending ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-1"></i>
                      Generating...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-magic mr-1"></i>
                      AI Generate
                    </>
                  )}
                </button>
              )}
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Video Title</label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-input rounded-md bg-background focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent"
                  placeholder="Enter video title"
                  value={formData.title}
                  onChange={(e) => handleInputChange("title", e.target.value)}
                  data-testid="input-video-title"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Description</label>
                <textarea
                  className="w-full px-3 py-2 border border-input rounded-md bg-background focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent h-20 resize-none"
                  placeholder="Enter video description"
                  value={formData.description}
                  onChange={(e) => handleInputChange("description", e.target.value)}
                  data-testid="textarea-description"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Tags</label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {formData.tags.map((tag: string, index: number) => (
                    <span
                      key={index}
                      className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full flex items-center"
                      data-testid={`tag-${tag.replace(/\s+/g, '-').toLowerCase()}`}
                    >
                      {tag}
                      <button
                        onClick={() => handleRemoveTag(tag)}
                        className="ml-1 hover:text-primary/70"
                        data-testid={`button-remove-tag-${tag.replace(/\s+/g, '-').toLowerCase()}`}
                      >
                        <i className="fas fa-times text-xs"></i>
                      </button>
                    </span>
                  ))}
                </div>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    className="flex-1 px-3 py-2 border border-input rounded-md bg-background focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent"
                    placeholder="Add tags"
                    value={formData.newTag}
                    onChange={(e) => handleInputChange("newTag", e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleAddTag()}
                    data-testid="input-new-tag"
                  />
                  <button
                    onClick={handleAddTag}
                    className="px-4 py-2 bg-muted hover:bg-muted/80 text-foreground rounded-md transition-colors"
                    data-testid="button-add-tag"
                  >
                    Add
                  </button>
                </div>
              </div>

              <button
                onClick={handleSaveMetadata}
                disabled={updateMetadataMutation.isPending}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-2 px-4 rounded-md font-medium transition-colors disabled:opacity-50"
                data-testid="button-save-metadata"
              >
                {updateMetadataMutation.isPending ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Saving...
                  </>
                ) : (
                  <>
                    <i className="fas fa-save mr-2"></i>
                    Save Metadata
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Project Summary */}
        <div className="space-y-6">
          {/* Progress Overview */}
          <div className="p-6 bg-gradient-to-br from-primary/10 to-accent/10 rounded-lg">
            <div className="text-center mb-4">
              <div className="relative w-16 h-16 mx-auto mb-3">
                <svg className="w-16 h-16" style={{ transform: "rotate(-90deg)" }} viewBox="0 0 64 64">
                  <circle cx="32" cy="32" r="28" stroke="var(--border)" strokeWidth="4" fill="none"/>
                  <circle 
                    cx="32" 
                    cy="32" 
                    r="28" 
                    stroke="var(--primary)" 
                    strokeWidth="4" 
                    fill="none"
                    strokeDasharray="175.93"
                    strokeDashoffset={175.93 - (175.93 * progressPercentage) / 100}
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-lg font-bold text-foreground" data-testid="text-progress-percentage">
                    {progressPercentage}%
                  </span>
                </div>
              </div>
              <h3 className="font-semibold text-foreground">Project Progress</h3>
              <p className="text-sm text-muted-foreground">
                {project ? `${project.currentStep} of ${project.totalSteps} steps completed` : "No active project"}
              </p>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Estimated completion</span>
                <span className="font-medium text-foreground" data-testid="text-estimated-completion">
                  45 minutes
                </span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Next step</span>
                <span className="font-medium text-accent">
                  {project?.currentStep === 1 ? "Voiceover Generation" : 
                   project?.currentStep === 2 ? "Audio Enhancement" :
                   project?.currentStep === 3 ? "Video Upload" : "Continue Workflow"}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div>
            <h3 className="font-medium text-foreground mb-3">Quick Actions</h3>
            <div className="space-y-2">
              <button className="w-full flex items-center justify-center px-4 py-3 bg-primary hover:bg-primary/90 text-primary-foreground rounded-lg font-medium transition-colors" data-testid="button-continue-workflow">
                <i className="fas fa-play mr-2"></i>Continue Workflow
              </button>
              <button className="w-full flex items-center justify-center px-4 py-2 border border-border hover:bg-muted/50 text-foreground rounded-lg transition-colors" data-testid="button-save-project">
                <i className="fas fa-save mr-2"></i>Save Project
              </button>
              <button className="w-full flex items-center justify-center px-4 py-2 border border-border hover:bg-muted/50 text-foreground rounded-lg transition-colors" data-testid="button-export-settings">
                <i className="fas fa-share mr-2"></i>Export Settings
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
