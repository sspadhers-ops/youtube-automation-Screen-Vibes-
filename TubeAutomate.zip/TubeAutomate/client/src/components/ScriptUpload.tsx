import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useFileUpload } from "@/hooks/useFileUpload";

interface ScriptUploadProps {
  projectId: string;
  script?: any;
}

export default function ScriptUpload({ projectId, script }: ScriptUploadProps) {
  const [dragActive, setDragActive] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("script", file);
      formData.append("type", "script");
      
      const response = await fetch(`/api/projects/${projectId}/script`, {
        method: "POST",
        body: formData,
      });
      
      if (!response.ok) {
        const error = await response.text();
        throw new Error(error);
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "complete"] });
      toast({
        title: "Script Uploaded",
        description: "Your script has been uploaded successfully and is ready for analysis.",
      });
    },
    onError: (error) => {
      toast({
        title: "Upload Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type === "text/plain" || file.name.endsWith(".txt")) {
        uploadMutation.mutate(file);
      } else {
        toast({
          title: "Invalid File Type",
          description: "Please upload a text file (.txt)",
          variant: "destructive",
        });
      }
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      uploadMutation.mutate(e.target.files[0]);
    }
  };

  const handleRemoveScript = () => {
    // TODO: Implement script removal
    toast({
      title: "Feature Coming Soon",
      description: "Script removal will be available in the next update.",
    });
  };

  return (
    <div className="bg-card rounded-xl shadow-sm border border-border p-8">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-foreground mb-2">Upload Script</h2>
        <p className="text-muted-foreground">Drag and drop your script file or browse to select</p>
      </div>

      {!script ? (
        <>
          {/* Upload Zone */}
          <div
            className={`border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-all ${
              dragActive
                ? "border-primary bg-primary/5"
                : "border-border hover:border-primary hover:bg-primary/5"
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            onClick={() => document.getElementById("script-file-input")?.click()}
            data-testid="area-script-upload"
          >
            <div className="space-y-4">
              <div className="mx-auto w-16 h-16 bg-muted rounded-full flex items-center justify-center">
                {uploadMutation.isPending ? (
                  <i className="fas fa-spinner fa-spin text-2xl text-muted-foreground"></i>
                ) : (
                  <i className="fas fa-file-text text-2xl text-muted-foreground"></i>
                )}
              </div>
              <div>
                <p className="text-lg font-medium text-foreground mb-1">
                  {uploadMutation.isPending ? "Uploading..." : "Drop your script file here"}
                </p>
                <p className="text-muted-foreground">or click to browse</p>
              </div>
              <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
                <span>Supports:</span>
                <span className="px-2 py-1 bg-muted rounded text-xs font-medium">.txt</span>
                <span className="px-2 py-1 bg-muted rounded text-xs font-medium">.docx</span>
                <span className="px-2 py-1 bg-muted rounded text-xs font-medium">.pdf</span>
              </div>
            </div>
            <input
              id="script-file-input"
              type="file"
              className="hidden"
              accept=".txt,.docx,.pdf"
              onChange={handleFileSelect}
              disabled={uploadMutation.isPending}
              data-testid="input-script-file"
            />
          </div>
        </>
      ) : (
        /* Uploaded File Display */
        <div className="p-4 bg-accent/10 border border-accent/20 rounded-lg" data-testid="area-uploaded-script">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-accent/20 rounded-lg flex items-center justify-center">
                <i className="fas fa-file-text text-accent"></i>
              </div>
              <div>
                <p className="font-medium text-foreground" data-testid="text-script-filename">
                  {script.fileName}
                </p>
                <p className="text-sm text-muted-foreground">
                  {(script.originalContent?.length || 0)} characters • Uploaded {new Date(script.createdAt).toLocaleString()}
                </p>
              </div>
            </div>
            <button 
              className="text-muted-foreground hover:text-foreground transition-colors"
              onClick={handleRemoveScript}
              data-testid="button-remove-script"
            >
              <i className="fas fa-times"></i>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
