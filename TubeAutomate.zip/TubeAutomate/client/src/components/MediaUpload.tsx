import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface MediaUploadProps {
  projectId: string;
  mediaFiles: any[];
}

interface UploadZoneProps {
  type: "face_video" | "tv_episode";
  title: string;
  description: string;
  icon: string;
  acceptedTypes: string;
  onUpload: (file: File) => void;
  isUploading: boolean;
  existingFile?: any;
}

function UploadZone({ type, title, description, icon, acceptedTypes, onUpload, isUploading, existingFile }: UploadZoneProps) {
  const [dragActive, setDragActive] = useState(false);
  
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      onUpload(e.dataTransfer.files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onUpload(e.target.files[0]);
    }
  };

  if (existingFile) {
    return (
      <div className="bg-card rounded-xl shadow-sm border border-border p-6">
        <div className="mb-4">
          <h3 className="text-lg font-semibold text-foreground mb-2">{title}</h3>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>

        <div className="p-4 bg-accent/10 border border-accent/20 rounded-lg" data-testid={`area-uploaded-${type}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-accent/20 rounded-lg flex items-center justify-center">
                <i className={`${icon} text-accent`}></i>
              </div>
              <div>
                <p className="font-medium text-foreground" data-testid={`text-${type}-filename`}>
                  {existingFile.fileName}
                </p>
                <p className="text-sm text-muted-foreground">
                  {Math.round(existingFile.fileSize / 1024 / 1024)} MB • Uploaded {new Date(existingFile.createdAt).toLocaleString()}
                </p>
              </div>
            </div>
            <button className="text-muted-foreground hover:text-foreground transition-colors" data-testid={`button-remove-${type}`}>
              <i className="fas fa-times"></i>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-xl shadow-sm border border-border p-6">
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-foreground mb-2">{title}</h3>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>

      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-all ${
          dragActive
            ? "border-primary bg-primary/5"
            : "border-border hover:border-primary hover:bg-primary/5"
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        onClick={() => document.getElementById(`${type}-file-input`)?.click()}
        data-testid={`area-${type}-upload`}
      >
        <div className="mx-auto w-12 h-12 bg-muted rounded-full flex items-center justify-center mb-3">
          {isUploading ? (
            <i className="fas fa-spinner fa-spin text-lg text-muted-foreground"></i>
          ) : (
            <i className={`${icon} text-lg text-muted-foreground`}></i>
          )}
        </div>
        <p className="font-medium text-foreground mb-1">
          {isUploading ? "Uploading..." : `Upload ${title.toLowerCase()}`}
        </p>
        <p className="text-sm text-muted-foreground mb-3">{acceptedTypes}</p>
        <button 
          className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:bg-primary/90 transition-colors"
          disabled={isUploading}
          data-testid={`button-choose-${type}`}
        >
          Choose File
        </button>
        <input
          id={`${type}-file-input`}
          type="file"
          className="hidden"
          accept="video/*"
          onChange={handleFileSelect}
          disabled={isUploading}
          data-testid={`input-${type}-file`}
        />
      </div>
    </div>
  );
}

export default function MediaUpload({ projectId, mediaFiles }: MediaUploadProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async ({ file, type }: { file: File; type: string }) => {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("type", type);
      
      const response = await fetch(`/api/projects/${projectId}/media`, {
        method: "POST",
        body: formData,
      });
      
      if (!response.ok) {
        const error = await response.text();
        throw new Error(error);
      }
      
      return response.json();
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "complete"] });
      toast({
        title: "Upload Complete",
        description: `${variables.type === "face_video" ? "Face video" : "TV episode"} has been uploaded successfully.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Upload Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleUpload = (file: File, type: string) => {
    uploadMutation.mutate({ file, type });
  };

  const faceVideoFile = mediaFiles.find(file => file.type === "face_video");
  const tvEpisodeFile = mediaFiles.find(file => file.type === "tv_episode");

  return (
    <div className="grid lg:grid-cols-2 gap-8">
      <UploadZone
        type="face_video"
        title="Face Video Upload"
        description="Upload your talking head video recording"
        icon="fas fa-video"
        acceptedTypes="MP4, MOV, AVI up to 500MB"
        onUpload={(file) => handleUpload(file, "face_video")}
        isUploading={uploadMutation.isPending}
        existingFile={faceVideoFile}
      />

      <UploadZone
        type="tv_episode"
        title="TV Episode Upload"
        description="Upload episode for extracting clips"
        icon="fas fa-tv"
        acceptedTypes="MP4, MOV, MKV up to 2GB"
        onUpload={(file) => handleUpload(file, "tv_episode")}
        isUploading={uploadMutation.isPending}
        existingFile={tvEpisodeFile}
      />
    </div>
  );
}
