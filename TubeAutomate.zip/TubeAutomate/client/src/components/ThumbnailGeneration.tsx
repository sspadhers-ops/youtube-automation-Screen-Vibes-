import { useMutation, useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ThumbnailGenerationProps {
  projectId: string;
  script?: any;
  metadata?: any;
}

const STYLE_OPTIONS = [
  "Modern Tech",
  "Minimalist",
  "Dramatic",
  "Professional",
];

const COLOR_SCHEMES = [
  { name: "Blue", color: "bg-blue-500", class: "border-primary" },
  { name: "Purple", color: "bg-purple-500", class: "border-border hover:border-primary" },
  { name: "Green", color: "bg-green-500", class: "border-border hover:border-primary" },
  { name: "Orange", color: "bg-orange-500", class: "border-border hover:border-primary" },
];

const FACE_POSITIONS = [
  { name: "Left", position: "left" },
  { name: "Center", position: "center" },
  { name: "Right", position: "right" },
];

export default function ThumbnailGeneration({ projectId, script, metadata }: ThumbnailGenerationProps) {
  const [customization, setCustomization] = useState({
    titleOverlay: "",
    style: "Modern Tech",
    colorScheme: "Blue",
    facePosition: "center",
  });
  const [selectedPrompt, setSelectedPrompt] = useState<string>("");
  const [generatedImages, setGeneratedImages] = useState<string[]>([]);
  const { toast } = useToast();

  // Get thumbnail prompts
  const { data: promptsData, isLoading: promptsLoading } = useQuery({
    queryKey: ["/api/projects", projectId, "thumbnails", "generate"],
    enabled: !!script,
  });

  const generateImageMutation = useMutation({
    mutationFn: async (prompt: string) => {
      const response = await apiRequest("POST", "/api/thumbnails/generate-image", { prompt });
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedImages(prev => [...prev, data.imageUrl]);
      toast({
        title: "Thumbnail Generated",
        description: "New thumbnail option has been created successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleGenerateImage = (prompt: string) => {
    setSelectedPrompt(prompt);
    generateImageMutation.mutate(prompt);
  };

  const handleCustomizationChange = (field: string, value: string) => {
    setCustomization(prev => ({ ...prev, [field]: value }));
  };

  const mockThumbnails = [
    "https://images.unsplash.com/photo-1677442136019-21780ecad995?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=225",
    "https://images.unsplash.com/photo-1531746790731-6c087fecd65a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=225",
    "https://images.unsplash.com/photo-1507146426996-ef05306b995a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=225",
    "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=225",
  ];

  const displayThumbnails = generatedImages.length > 0 ? generatedImages : mockThumbnails;

  if (!script) {
    return (
      <div className="bg-card rounded-xl shadow-sm border border-border p-8">
        <div className="text-center py-8">
          <i className="fas fa-image text-3xl text-muted-foreground mb-4"></i>
          <h3 className="text-lg font-semibold text-foreground mb-2">Thumbnail Generation</h3>
          <p className="text-muted-foreground">Upload a script first to generate thumbnails</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-xl shadow-sm border border-border p-8">
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-foreground mb-2">AI Thumbnail Generation</h2>
        <p className="text-muted-foreground">Generate eye-catching thumbnails based on your script theme</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Thumbnail Options */}
        <div className="lg:col-span-2">
          <h3 className="font-medium text-foreground mb-4">Generated Options</h3>
          {promptsLoading ? (
            <div className="text-center py-8">
              <i className="fas fa-spinner fa-spin text-2xl text-primary mb-4"></i>
              <p className="text-muted-foreground">Generating thumbnail concepts...</p>
            </div>
          ) : (
            <>
              <div className="grid sm:grid-cols-2 gap-4">
                {displayThumbnails.slice(0, 4).map((thumbnail, index) => {
                  const isSelected = index === 2; // Default selection for demo
                  return (
                    <div
                      key={index}
                      className={`relative group cursor-pointer ${
                        isSelected ? "border-2 border-primary rounded-lg" : ""
                      }`}
                      data-testid={`thumbnail-option-${index}`}
                    >
                      <img
                        src={thumbnail}
                        alt={`Thumbnail option ${index + 1}`}
                        className="w-full h-32 object-cover rounded-lg"
                      />
                      <div className={`absolute inset-0 rounded-lg flex items-center justify-center transition-opacity ${
                        isSelected
                          ? "bg-primary/20 opacity-100"
                          : "bg-black/50 opacity-0 group-hover:opacity-100"
                      }`}>
                        <button className={`px-4 py-2 rounded-md text-sm font-medium ${
                          isSelected
                            ? "bg-primary text-primary-foreground"
                            : "bg-white text-black"
                        }`} data-testid={`button-select-thumbnail-${index}`}>
                          <i className={`mr-2 ${isSelected ? "fas fa-check" : "fas fa-check"}`}></i>
                          {isSelected ? "Selected" : "Select"}
                        </button>
                      </div>
                      {index === 0 && (
                        <div className="absolute top-2 right-2 bg-primary text-primary-foreground text-xs px-2 py-1 rounded">
                          AI
                        </div>
                      )}
                      {index === 1 && (
                        <div className="absolute top-2 right-2 bg-accent text-accent-foreground text-xs px-2 py-1 rounded">
                          Popular
                        </div>
                      )}
                      {index === 2 && (
                        <div className="absolute top-2 right-2 bg-primary text-primary-foreground text-xs px-2 py-1 rounded">
                          Best
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              <button
                onClick={() => {
                  if (promptsData?.prompts?.[0]) {
                    handleGenerateImage(promptsData.prompts[0]);
                  }
                }}
                disabled={generateImageMutation.isPending || !promptsData?.prompts}
                className="mt-4 px-4 py-2 border border-border hover:bg-muted/50 text-foreground rounded-md transition-colors disabled:opacity-50"
                data-testid="button-generate-more-thumbnails"
              >
                {generateImageMutation.isPending ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Generating...
                  </>
                ) : (
                  <>
                    <i className="fas fa-refresh mr-2"></i>
                    Generate More Options
                  </>
                )}
              </button>
            </>
          )}
        </div>

        {/* Customization Panel */}
        <div className="space-y-6">
          <div>
            <h3 className="font-medium text-foreground mb-4">Customize</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Title Overlay</label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-input rounded-md bg-background focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent text-sm"
                  placeholder="Add title text"
                  value={customization.titleOverlay}
                  onChange={(e) => handleCustomizationChange("titleOverlay", e.target.value)}
                  data-testid="input-thumbnail-title"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Style</label>
                <select
                  className="w-full px-3 py-2 border border-input rounded-md bg-background focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent text-sm"
                  value={customization.style}
                  onChange={(e) => handleCustomizationChange("style", e.target.value)}
                  data-testid="select-thumbnail-style"
                >
                  {STYLE_OPTIONS.map(style => (
                    <option key={style} value={style}>{style}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Color Scheme</label>
                <div className="flex space-x-2">
                  {COLOR_SCHEMES.map((scheme, index) => (
                    <button
                      key={scheme.name}
                      onClick={() => handleCustomizationChange("colorScheme", scheme.name)}
                      className={`w-8 h-8 ${scheme.color} rounded-full border-2 transition-colors ${
                        customization.colorScheme === scheme.name ? scheme.class : "border-border hover:border-primary"
                      }`}
                      data-testid={`button-color-${scheme.name.toLowerCase()}`}
                    ></button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Face Position</label>
                <div className="grid grid-cols-3 gap-2">
                  {FACE_POSITIONS.map((position, index) => (
                    <button
                      key={position.position}
                      onClick={() => handleCustomizationChange("facePosition", position.position)}
                      className={`p-2 border rounded transition-colors ${
                        customization.facePosition === position.position
                          ? "border-primary bg-primary/5"
                          : "border-border hover:border-primary hover:bg-primary/5"
                      }`}
                      data-testid={`button-face-position-${position.position}`}
                    >
                      <div className="w-full h-8 bg-muted rounded flex items-center justify-center">
                        <div className="w-3 h-3 bg-foreground rounded-full"></div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-2 px-4 rounded-md font-medium transition-colors" data-testid="button-download-thumbnail">
              <i className="fas fa-download mr-2"></i>Download
            </button>
            <button className="w-full border border-border hover:bg-muted/50 text-foreground py-2 px-4 rounded-md transition-colors" data-testid="button-advanced-edit">
              <i className="fas fa-edit mr-2"></i>Advanced Edit
            </button>
          </div>

          {/* Thumbnail Preview */}
          <div className="p-3 border border-border rounded-lg">
            <p className="text-xs font-medium text-foreground mb-2">Preview (1280x720)</p>
            <img
              src="https://images.unsplash.com/photo-1507146426996-ef05306b995a?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=113"
              alt="Thumbnail preview"
              className="w-full rounded"
              data-testid="img-thumbnail-preview"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
