interface SidebarProps {
  currentProject: any;
  allProjects: any[];
  onSelectProject: (projectId: string) => void;
  onCreateProject: () => void;
}

export default function Sidebar({ currentProject, allProjects, onSelectProject, onCreateProject }: SidebarProps) {
  const getWorkflowSteps = () => [
    { id: 1, title: "Script Upload", description: "Upload and analyze script content", completed: !!currentProject && currentProject.currentStep > 1 },
    { id: 2, title: "Voiceover Generation", description: "AI voice synthesis with Google Studio", completed: !!currentProject && currentProject.currentStep > 2 },
    { id: 3, title: "Audio Enhancement", description: "Process audio through Adobe Enhance", completed: !!currentProject && currentProject.currentStep > 3 },
    { id: 4, title: "Video Upload", description: "Face video and TV episode clips", completed: !!currentProject && currentProject.currentStep > 4 },
    { id: 5, title: "Auto-Editing", description: "AI-powered video editing and sync", completed: !!currentProject && currentProject.currentStep > 5 },
    { id: 6, title: "Thumbnail Generation", description: "AI-generated thumbnails", completed: !!currentProject && currentProject.currentStep > 6 },
    { id: 7, title: "YouTube Upload", description: "Auto-schedule and publish", completed: !!currentProject && currentProject.currentStep > 7 },
  ];

  const workflowSteps = getWorkflowSteps();
  const progressPercentage = currentProject ? Math.round((currentProject.currentStep / currentProject.totalSteps) * 100) : 0;

  return (
    <div className="w-80 bg-card border-r border-border flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
            <i className="fas fa-video text-white text-lg"></i>
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">YouTube Studio</h1>
            <p className="text-sm text-muted-foreground">Automation Workflow</p>
          </div>
        </div>
        
        {/* Project Selector */}
        <div className="relative">
          <button className="w-full flex items-center justify-between p-3 bg-muted rounded-md hover:bg-muted/80 transition-colors" data-testid="button-project-selector">
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-accent rounded-full"></div>
              <span className="font-medium text-foreground truncate">
                {currentProject ? currentProject.name : "No Project Selected"}
              </span>
            </div>
            <i className="fas fa-chevron-down text-muted-foreground"></i>
          </button>
        </div>
      </div>

      {/* Workflow Steps */}
      <div className="flex-1 p-6 overflow-y-auto">
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-4">Workflow Steps</h2>
        <div className="space-y-4">
          {workflowSteps.map((step, index) => (
            <div key={step.id} className={`workflow-step ${step.completed ? 'completed' : ''}`}>
              <div className="flex items-start space-x-3">
                <div className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center mt-1 ${
                  step.completed 
                    ? 'bg-accent' 
                    : currentProject && currentProject.currentStep === step.id
                      ? 'bg-primary'
                      : 'bg-border'
                }`}>
                  {step.completed ? (
                    <i className="fas fa-check text-white text-xs"></i>
                  ) : (
                    <span className={`text-xs font-semibold ${
                      currentProject && currentProject.currentStep === step.id ? 'text-white' : 'text-muted-foreground'
                    }`}>
                      {step.id}
                    </span>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className={`text-sm font-medium ${
                    step.completed || (currentProject && currentProject.currentStep === step.id)
                      ? 'text-foreground'
                      : 'text-muted-foreground'
                  }`}>
                    {step.title}
                  </h3>
                  <p className="text-xs text-muted-foreground mt-1">{step.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Progress Summary */}
        {currentProject && (
          <div className="mt-8 p-4 bg-muted/30 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-foreground">Overall Progress</span>
              <span className="text-sm text-muted-foreground" data-testid="text-progress-status">
                {currentProject.currentStep}/{currentProject.totalSteps} Complete
              </span>
            </div>
            <div className="w-full bg-border rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-primary to-accent h-2 rounded-full transition-all duration-300"
                style={{ width: `${progressPercentage}%` }}
              ></div>
            </div>
          </div>
        )}

        {/* Recent Projects */}
        {allProjects.length > 0 && (
          <div className="mt-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Recent Projects</h3>
              <button 
                onClick={onCreateProject}
                className="text-xs text-primary hover:text-primary/80 transition-colors"
                data-testid="button-create-new-project"
              >
                <i className="fas fa-plus mr-1"></i>New
              </button>
            </div>
            <div className="space-y-2">
              {allProjects.slice(0, 3).map((project: any) => (
                <button
                  key={project.id}
                  onClick={() => onSelectProject(project.id)}
                  className={`w-full p-3 text-left rounded-lg transition-colors ${
                    currentProject && project.id === currentProject.id
                      ? 'bg-primary/10 border border-primary/20'
                      : 'border border-border hover:bg-muted/50'
                  }`}
                  data-testid={`button-recent-project-${project.id}`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="text-sm font-medium text-foreground truncate">{project.name}</h4>
                    <span className="text-xs text-muted-foreground">
                      {Math.floor((Date.now() - new Date(project.updatedAt).getTime()) / (1000 * 60 * 60 * 24))}d ago
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Step {project.currentStep}/7 • {(project.status || 'pending').replace('_', ' ')}
                  </p>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
