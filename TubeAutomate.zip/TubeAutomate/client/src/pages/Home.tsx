import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useParams } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/Sidebar";
import ScriptUpload from "@/components/ScriptUpload";
import AIAnalysis from "@/components/AIAnalysis";
import MediaUpload from "@/components/MediaUpload";
import AudioProcessing from "@/components/AudioProcessing";
import ProjectDashboard from "@/components/ProjectDashboard";
import ThumbnailGeneration from "@/components/ThumbnailGeneration";

export default function Home() {
  const { id } = useParams<{ id?: string }>();
  const [currentProjectId, setCurrentProjectId] = useState<string | null>(id || null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get current project data
  const { data: projectData, isLoading } = useQuery({
    queryKey: ["/api/projects", currentProjectId, "complete"],
    enabled: !!currentProjectId,
  });

  // Get all projects for sidebar
  const { data: allProjects } = useQuery({
    queryKey: ["/api/projects"],
  });

  // Create new project mutation
  const createProjectMutation = useMutation({
    mutationFn: async (name: string) => {
      const response = await apiRequest("POST", "/api/projects", { name });
      return response.json();
    },
    onSuccess: (project) => {
      setCurrentProjectId(project.id);
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({
        title: "Project Created",
        description: `Project "${project.name}" has been created successfully.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create project: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const handleCreateProject = () => {
    const projectName = `Project ${new Date().toLocaleDateString()}`;
    createProjectMutation.mutate(projectName);
  };

  const handleSelectProject = (projectId: string) => {
    setCurrentProjectId(projectId);
    window.history.pushState({}, "", `/project/${projectId}`);
  };

  if (!currentProjectId) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-6">
          <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center mx-auto">
            <i className="fas fa-video text-white text-2xl"></i>
          </div>
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">YouTube Automation Studio</h1>
            <p className="text-muted-foreground mb-6">Create professional video content with AI-powered workflow</p>
            <button
              onClick={handleCreateProject}
              disabled={createProjectMutation.isPending}
              className="bg-primary hover:bg-primary/90 text-primary-foreground px-6 py-3 rounded-lg font-medium transition-colors"
              data-testid="button-create-project"
            >
              {createProjectMutation.isPending ? (
                <>
                  <i className="fas fa-spinner fa-spin mr-2"></i>
                  Creating...
                </>
              ) : (
                <>
                  <i className="fas fa-plus mr-2"></i>
                  Create New Project
                </>
              )}
            </button>
          </div>
          {allProjects && allProjects.length > 0 && (
            <div className="mt-8">
              <h3 className="text-lg font-semibold text-foreground mb-4">Recent Projects</h3>
              <div className="space-y-2">
                {allProjects.slice(0, 5).map((project: any) => (
                  <button
                    key={project.id}
                    onClick={() => handleSelectProject(project.id)}
                    className="w-full p-3 text-left border border-border rounded-lg hover:border-primary hover:bg-primary/5 transition-colors"
                    data-testid={`button-select-project-${project.id}`}
                  >
                    <div className="font-medium text-foreground">{project.name}</div>
                    <div className="text-sm text-muted-foreground">
                      Step {project.currentStep} of {project.totalSteps} • {(project.status || 'pending').replace('_', ' ')}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <i className="fas fa-spinner fa-spin text-3xl text-primary mb-4"></i>
          <p className="text-muted-foreground">Loading project...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-background">
      <Sidebar
        currentProject={projectData?.project}
        allProjects={allProjects || []}
        onSelectProject={handleSelectProject}
        onCreateProject={handleCreateProject}
      />
      
      <div className="flex-1 overflow-hidden">
        {/* Header Bar */}
        <header className="bg-card border-b border-border px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Script Upload & Analysis</h1>
              <p className="text-muted-foreground">Upload your script and let AI analyze and improve it</p>
            </div>
            <div className="flex items-center space-x-4">
              <button className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="button-history">
                <i className="fas fa-history mr-2"></i>History
              </button>
              <button className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="button-settings">
                <i className="fas fa-cog mr-2"></i>Settings
              </button>
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full"></div>
            </div>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-8">
          <div className="max-w-6xl mx-auto space-y-8">
            <ScriptUpload projectId={currentProjectId} script={projectData?.script} />
            
            {projectData?.script && (
              <AIAnalysis script={projectData.script} projectId={currentProjectId} />
            )}
            
            <MediaUpload projectId={currentProjectId} mediaFiles={projectData?.mediaFiles || []} />
            
            <AudioProcessing 
              projectId={currentProjectId} 
              audioProcessing={projectData?.audioProcessing}
              script={projectData?.script}
            />
            
            <ProjectDashboard
              project={projectData?.project}
              script={projectData?.script}
              mediaFiles={projectData?.mediaFiles || []}
              audioProcessing={projectData?.audioProcessing}
              metadata={projectData?.metadata}
              projectId={currentProjectId}
            />
            
            <ThumbnailGeneration
              projectId={currentProjectId}
              script={projectData?.script}
              metadata={projectData?.metadata}
            />
          </div>
        </main>
      </div>
    </div>
  );
}
