# YouTube Automation Studio

## Overview

This is a comprehensive YouTube content automation platform built with a modern full-stack architecture. The application provides an end-to-end workflow for creating YouTube videos, from script upload and AI analysis to automated video editing and thumbnail generation. It features a multi-step pipeline that guides users through script improvement, voiceover generation, audio enhancement, video processing, and final content preparation for YouTube upload.

The platform leverages AI services for content analysis, voice synthesis, and creative generation, while providing a user-friendly interface for managing video production projects. The workflow consists of 7 distinct steps: script upload/analysis, voiceover generation, audio enhancement, media upload (face video and TV episodes), auto-editing, thumbnail generation, and YouTube upload preparation.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

The client-side application is built with React and TypeScript, using a component-based architecture with modern tooling:

- **Framework**: React with TypeScript for type safety and developer experience
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Styling**: Tailwind CSS with CSS variables for theming, using the shadcn/ui component system
- **Build Tool**: Vite for fast development and optimized production builds
- **UI Components**: Comprehensive component library built on Radix UI primitives for accessibility

The frontend follows a modular structure with clearly separated concerns - components handle presentation logic, hooks manage stateful behavior, and services handle API communication. The application uses a sidebar-based layout with project selection and workflow step tracking.

### Backend Architecture

The server is built with Express.js and follows a RESTful API design pattern:

- **Runtime**: Node.js with TypeScript and ESM modules
- **Framework**: Express.js with structured route handling
- **File Handling**: Multer for multipart file uploads with validation and storage management
- **API Design**: RESTful endpoints organized by resource type (projects, scripts, media files, audio processing)
- **Error Handling**: Centralized error handling middleware with structured error responses
- **Logging**: Request/response logging with performance metrics

The server implements a service layer pattern, separating business logic from route handlers. File uploads are handled with proper validation, storage organization, and metadata tracking.

### Data Storage Solutions

The application uses a dual storage approach:

- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Management**: Drizzle Kit for migrations and schema evolution
- **Connection Pooling**: Neon Database serverless connection pooling for scalability
- **File Storage**: Local filesystem with organized directory structure for uploaded media files
- **In-Memory Fallback**: Memory-based storage implementation for development and testing

The database schema includes tables for projects, scripts, media files, audio processing jobs, and content metadata, with proper foreign key relationships and indexing.

### Authentication and Authorization

Currently implements a session-based approach:

- **Session Management**: Express sessions with PostgreSQL session store (connect-pg-simple)
- **Security**: CORS configuration and request validation
- **File Access Control**: Project-based file isolation and access patterns

### External Service Integrations

The platform integrates with several AI and media processing services:

- **OpenAI Integration**: GPT-5 model for script analysis, improvement suggestions, and thumbnail prompt generation
- **Google Studio**: Voice synthesis API for generating natural-sounding voiceovers
- **Adobe Enhance**: Audio processing API for improving voiceover quality
- **Image Generation**: AI-powered thumbnail creation with customization options

### Workflow Management

The application implements a step-based workflow system:

- **Project State Management**: Tracks current step and progress through the 7-step pipeline
- **Step Dependencies**: Ensures proper ordering and completion of workflow stages
- **File Processing Pipeline**: Handles various media types (scripts, audio, video) with appropriate validation
- **Status Tracking**: Real-time updates on processing status for each workflow component

### Development and Deployment

- **Development**: Hot module replacement with Vite, TypeScript checking, and development middleware
- **Build Process**: Separate client and server builds with proper bundling
- **Environment Configuration**: Environment-based configuration for database connections and API keys
- **Asset Management**: Proper asset handling and static file serving in production