import {
  projects,
  scripts,
  mediaFiles,
  audioProcessing,
  contentMetadata,
  type Project,
  type InsertProject,
  type Script,
  type InsertScript,
  type MediaFile,
  type InsertMediaFile,
  type AudioProcessing,
  type InsertAudioProcessing,
  type ContentMetadata,
  type InsertContentMetadata,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Projects
  createProject(project: InsertProject): Promise<Project>;
  getProject(id: string): Promise<Project | undefined>;
  getAllProjects(): Promise<Project[]>;
  updateProject(id: string, updates: Partial<Project>): Promise<Project | undefined>;
  
  // Scripts
  createScript(script: InsertScript): Promise<Script>;
  getScriptByProjectId(projectId: string): Promise<Script | undefined>;
  updateScript(id: string, updates: Partial<Script>): Promise<Script | undefined>;
  
  // Media Files
  createMediaFile(mediaFile: InsertMediaFile): Promise<MediaFile>;
  getMediaFilesByProjectId(projectId: string): Promise<MediaFile[]>;
  getMediaFilesByType(projectId: string, type: string): Promise<MediaFile[]>;
  updateMediaFile(id: string, updates: Partial<MediaFile>): Promise<MediaFile | undefined>;
  
  // Audio Processing
  createAudioProcessing(audioProcessing: InsertAudioProcessing): Promise<AudioProcessing>;
  getAudioProcessingByProjectId(projectId: string): Promise<AudioProcessing | undefined>;
  updateAudioProcessing(id: string, updates: Partial<AudioProcessing>): Promise<AudioProcessing | undefined>;
  
  // Content Metadata
  createContentMetadata(contentMetadata: InsertContentMetadata): Promise<ContentMetadata>;
  getContentMetadataByProjectId(projectId: string): Promise<ContentMetadata | undefined>;
  updateContentMetadata(id: string, updates: Partial<ContentMetadata>): Promise<ContentMetadata | undefined>;
}

export class MemStorage implements IStorage {
  private projects: Map<string, Project> = new Map();
  private scripts: Map<string, Script> = new Map();
  private mediaFiles: Map<string, MediaFile> = new Map();
  private audioProcessing: Map<string, AudioProcessing> = new Map();
  private contentMetadata: Map<string, ContentMetadata> = new Map();

  // Projects
  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = randomUUID();
    const now = new Date();
    const project: Project = {
      ...insertProject,
      id,
      status: insertProject.status || "script_upload",
      currentStep: insertProject.currentStep || 1,
      totalSteps: insertProject.totalSteps || 7,
      createdAt: now,
      updatedAt: now,
    };
    this.projects.set(id, project);
    return project;
  }

  async getProject(id: string): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async getAllProjects(): Promise<Project[]> {
    return Array.from(this.projects.values()).sort(
      (a, b) => b.updatedAt.getTime() - a.updatedAt.getTime()
    );
  }

  async updateProject(id: string, updates: Partial<Project>): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;
    
    const updatedProject = {
      ...project,
      ...updates,
      updatedAt: new Date(),
    };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  // Scripts
  async createScript(insertScript: InsertScript): Promise<Script> {
    const id = randomUUID();
    const script: Script = {
      ...insertScript,
      id,
      improvedContent: insertScript.improvedContent || null,
      analysis: insertScript.analysis || null,
      createdAt: new Date(),
    };
    this.scripts.set(id, script);
    return script;
  }

  async getScriptByProjectId(projectId: string): Promise<Script | undefined> {
    return Array.from(this.scripts.values()).find(
      script => script.projectId === projectId
    );
  }

  async updateScript(id: string, updates: Partial<Script>): Promise<Script | undefined> {
    const script = this.scripts.get(id);
    if (!script) return undefined;
    
    const updatedScript = { ...script, ...updates };
    this.scripts.set(id, updatedScript);
    return updatedScript;
  }

  // Media Files
  async createMediaFile(insertMediaFile: InsertMediaFile): Promise<MediaFile> {
    const id = randomUUID();
    const mediaFile: MediaFile = {
      ...insertMediaFile,
      id,
      status: insertMediaFile.status || "uploaded",
      metadata: insertMediaFile.metadata || null,
      createdAt: new Date(),
    };
    this.mediaFiles.set(id, mediaFile);
    return mediaFile;
  }

  async getMediaFilesByProjectId(projectId: string): Promise<MediaFile[]> {
    return Array.from(this.mediaFiles.values()).filter(
      file => file.projectId === projectId
    );
  }

  async getMediaFilesByType(projectId: string, type: string): Promise<MediaFile[]> {
    return Array.from(this.mediaFiles.values()).filter(
      file => file.projectId === projectId && file.type === type
    );
  }

  async updateMediaFile(id: string, updates: Partial<MediaFile>): Promise<MediaFile | undefined> {
    const mediaFile = this.mediaFiles.get(id);
    if (!mediaFile) return undefined;
    
    const updatedMediaFile = { ...mediaFile, ...updates };
    this.mediaFiles.set(id, updatedMediaFile);
    return updatedMediaFile;
  }

  // Audio Processing
  async createAudioProcessing(insertAudioProcessing: InsertAudioProcessing): Promise<AudioProcessing> {
    const id = randomUUID();
    const audioProc: AudioProcessing = {
      ...insertAudioProcessing,
      id,
      status: insertAudioProcessing.status || "pending",
      generatedAudioPath: insertAudioProcessing.generatedAudioPath || null,
      enhancedAudioPath: insertAudioProcessing.enhancedAudioPath || null,
      duration: insertAudioProcessing.duration || null,
      createdAt: new Date(),
    };
    this.audioProcessing.set(id, audioProc);
    return audioProc;
  }

  async getAudioProcessingByProjectId(projectId: string): Promise<AudioProcessing | undefined> {
    return Array.from(this.audioProcessing.values()).find(
      audio => audio.projectId === projectId
    );
  }

  async updateAudioProcessing(id: string, updates: Partial<AudioProcessing>): Promise<AudioProcessing | undefined> {
    const audioProc = this.audioProcessing.get(id);
    if (!audioProc) return undefined;
    
    const updatedAudioProc = { ...audioProc, ...updates };
    this.audioProcessing.set(id, updatedAudioProc);
    return updatedAudioProc;
  }

  // Content Metadata
  async createContentMetadata(insertContentMetadata: InsertContentMetadata): Promise<ContentMetadata> {
    const id = randomUUID();
    const metadata: ContentMetadata = {
      ...insertContentMetadata,
      id,
      tags: insertContentMetadata.tags || null,
      thumbnailPrompt: insertContentMetadata.thumbnailPrompt || null,
      selectedThumbnailPath: insertContentMetadata.selectedThumbnailPath || null,
      createdAt: new Date(),
    };
    this.contentMetadata.set(id, metadata);
    return metadata;
  }

  async getContentMetadataByProjectId(projectId: string): Promise<ContentMetadata | undefined> {
    return Array.from(this.contentMetadata.values()).find(
      metadata => metadata.projectId === projectId
    );
  }

  async updateContentMetadata(id: string, updates: Partial<ContentMetadata>): Promise<ContentMetadata | undefined> {
    const metadata = this.contentMetadata.get(id);
    if (!metadata) return undefined;
    
    const updatedMetadata = { ...metadata, ...updates };
    this.contentMetadata.set(id, updatedMetadata);
    return updatedMetadata;
  }
}

export const storage = new MemStorage();
