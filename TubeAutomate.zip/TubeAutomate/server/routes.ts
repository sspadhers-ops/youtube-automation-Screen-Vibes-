import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { upload, readScriptFile } from "./services/fileUpload";
import { analyzeScript, generateThumbnailPrompts, generateThumbnailImage, generateVideoMetadata } from "./services/openai";
import { insertProjectSchema, insertScriptSchema, insertMediaFileSchema, insertAudioProcessingSchema, insertContentMetadataSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Projects
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getAllProjects();
      res.json(projects);
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const projectData = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(projectData);
      res.status(201).json(project);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.getProject(req.params.id);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.patch("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.updateProject(req.params.id, req.body);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Script upload and analysis
  app.post("/api/projects/:projectId/script", upload.single("script"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No script file provided" });
      }

      const scriptContent = await readScriptFile(req.file.path, req.file.mimetype);
      
      const scriptData = {
        projectId: req.params.projectId,
        fileName: req.file.originalname,
        originalContent: scriptContent,
      };

      const script = await storage.createScript(scriptData);
      
      // Update project step
      await storage.updateProject(req.params.projectId, {
        status: "script_uploaded",
        currentStep: 2,
      });

      res.status(201).json(script);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.post("/api/scripts/:id/analyze", async (req, res) => {
    try {
      const script = await storage.getScriptByProjectId(req.body.projectId);
      if (!script) {
        return res.status(404).json({ error: "Script not found" });
      }

      const analysis = await analyzeScript(script.originalContent);
      
      const updatedScript = await storage.updateScript(script.id, {
        analysis,
        improvedContent: analysis.improvedContent,
      });

      res.json(updatedScript);
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Media file uploads
  app.post("/api/projects/:projectId/media", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file provided" });
      }

      const mediaFileData = {
        projectId: req.params.projectId,
        type: req.body.type,
        fileName: req.file.originalname,
        filePath: req.file.path,
        fileSize: req.file.size,
        mimeType: req.file.mimetype,
      };

      const mediaFile = await storage.createMediaFile(mediaFileData);
      res.status(201).json(mediaFile);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.get("/api/projects/:projectId/media", async (req, res) => {
    try {
      const mediaFiles = await storage.getMediaFilesByProjectId(req.params.projectId);
      res.json(mediaFiles);
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.get("/api/projects/:projectId/media/:type", async (req, res) => {
    try {
      const mediaFiles = await storage.getMediaFilesByType(req.params.projectId, req.params.type);
      res.json(mediaFiles);
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Audio processing
  app.post("/api/projects/:projectId/audio", async (req, res) => {
    try {
      const audioProcessingData = insertAudioProcessingSchema.parse({
        ...req.body,
        projectId: req.params.projectId,
      });

      const audioProcessing = await storage.createAudioProcessing(audioProcessingData);
      
      // Update project step
      await storage.updateProject(req.params.projectId, {
        status: "audio_processing",
        currentStep: 3,
      });

      res.status(201).json(audioProcessing);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.get("/api/projects/:projectId/audio", async (req, res) => {
    try {
      const audioProcessing = await storage.getAudioProcessingByProjectId(req.params.projectId);
      if (!audioProcessing) {
        return res.status(404).json({ error: "Audio processing not found" });
      }
      res.json(audioProcessing);
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Content metadata
  app.post("/api/projects/:projectId/metadata", async (req, res) => {
    try {
      const metadataData = insertContentMetadataSchema.parse({
        ...req.body,
        projectId: req.params.projectId,
      });

      const metadata = await storage.createContentMetadata(metadataData);
      res.status(201).json(metadata);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.get("/api/projects/:projectId/metadata", async (req, res) => {
    try {
      const metadata = await storage.getContentMetadataByProjectId(req.params.projectId);
      if (!metadata) {
        return res.status(404).json({ error: "Metadata not found" });
      }
      res.json(metadata);
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.patch("/api/projects/:projectId/metadata", async (req, res) => {
    try {
      const metadata = await storage.getContentMetadataByProjectId(req.params.projectId);
      if (!metadata) {
        return res.status(404).json({ error: "Metadata not found" });
      }

      const updatedMetadata = await storage.updateContentMetadata(metadata.id, req.body);
      res.json(updatedMetadata);
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // AI-powered features
  app.post("/api/projects/:projectId/generate-metadata", async (req, res) => {
    try {
      const script = await storage.getScriptByProjectId(req.params.projectId);
      if (!script) {
        return res.status(404).json({ error: "Script not found" });
      }

      const metadata = await generateVideoMetadata(script.originalContent);
      res.json(metadata);
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.post("/api/projects/:projectId/thumbnails/generate", async (req, res) => {
    try {
      const script = await storage.getScriptByProjectId(req.params.projectId);
      const metadata = await storage.getContentMetadataByProjectId(req.params.projectId);
      
      if (!script) {
        return res.status(404).json({ error: "Script not found" });
      }

      const title = metadata?.title || "Untitled Video";
      const prompts = await generateThumbnailPrompts(script.originalContent, title);
      
      res.json({ prompts });
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.post("/api/thumbnails/generate-image", async (req, res) => {
    try {
      const { prompt } = req.body;
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required" });
      }

      const imageUrl = await generateThumbnailImage(prompt);
      res.json({ imageUrl });
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Get project with all related data
  app.get("/api/projects/:id/complete", async (req, res) => {
    try {
      const project = await storage.getProject(req.params.id);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }

      const script = await storage.getScriptByProjectId(req.params.id);
      const mediaFiles = await storage.getMediaFilesByProjectId(req.params.id);
      const audioProcessing = await storage.getAudioProcessingByProjectId(req.params.id);
      const metadata = await storage.getContentMetadataByProjectId(req.params.id);

      res.json({
        project,
        script,
        mediaFiles,
        audioProcessing,
        metadata,
      });
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
