import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || ""
});

export interface ScriptAnalysis {
  grammar: { status: string; message: string };
  engagement: { status: string; message: string; suggestions: string[] };
  pacing: { status: string; message: string; suggestions: string[] };
  improvedContent?: string;
}

export async function analyzeScript(scriptContent: string): Promise<ScriptAnalysis> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are a YouTube content optimization expert. Analyze the script for grammar, engagement, and pacing. 
          Provide specific, actionable feedback and suggest improvements. 
          Respond with JSON in this exact format: 
          {
            "grammar": {"status": "good|needs_improvement", "message": "detailed feedback"},
            "engagement": {"status": "good|needs_improvement", "message": "feedback", "suggestions": ["suggestion1", "suggestion2"]},
            "pacing": {"status": "good|needs_improvement", "message": "feedback", "suggestions": ["suggestion1", "suggestion2"]},
            "improvedContent": "improved version of the script"
          }`
        },
        {
          role: "user",
          content: `Analyze this YouTube script and provide detailed feedback:\n\n${scriptContent}`
        }
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    throw new Error(`Failed to analyze script: ${error instanceof Error ? error.message : "Unknown error"}`);
  }
}

export async function generateThumbnailPrompts(scriptContent: string, title: string): Promise<string[]> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are a YouTube thumbnail design expert. Generate compelling DALL-E prompts for eye-catching thumbnails based on the script content and title.
          Create 4 different prompt variations focusing on different visual styles.
          Respond with JSON in this format: {"prompts": ["prompt1", "prompt2", "prompt3", "prompt4"]}`
        },
        {
          role: "user",
          content: `Generate thumbnail prompts for:\nTitle: ${title}\nScript: ${scriptContent.substring(0, 500)}`
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result.prompts || [];
  } catch (error) {
    throw new Error(`Failed to generate thumbnail prompts: ${error instanceof Error ? error.message : "Unknown error"}`);
  }
}

export async function generateThumbnailImage(prompt: string): Promise<string> {
  try {
    const response = await openai.images.generate({
      model: "dall-e-3",
      prompt: `YouTube thumbnail: ${prompt}. Professional, eye-catching, high contrast, clear text overlay area, 16:9 aspect ratio`,
      n: 1,
      size: "1792x1024",
      quality: "hd",
    });

    return response.data?.[0]?.url || "";
  } catch (error) {
    throw new Error(`Failed to generate thumbnail: ${error instanceof Error ? error.message : "Unknown error"}`);
  }
}

export async function generateVideoMetadata(scriptContent: string): Promise<{
  title: string;
  description: string;
  tags: string[];
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are a YouTube SEO expert. Generate optimized title, description, and tags for maximum discoverability.
          Respond with JSON in this format:
          {
            "title": "engaging title under 60 characters",
            "description": "detailed description with keywords",
            "tags": ["tag1", "tag2", "tag3", "tag4", "tag5"]
          }`
        },
        {
          role: "user",
          content: `Generate YouTube metadata for this script:\n\n${scriptContent.substring(0, 1000)}`
        }
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    throw new Error(`Failed to generate video metadata: ${error instanceof Error ? error.message : "Unknown error"}`);
  }
}
