import multer from "multer";
import path from "path";
import fs from "fs";
import { randomUUID } from "crypto";

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Storage configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = path.join(uploadsDir, req.params.projectId || "temp");
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true });
    }
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = randomUUID();
    const ext = path.extname(file.originalname);
    cb(null, `${uniqueSuffix}${ext}`);
  }
});

// File filter
const fileFilter = (req: any, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
  const allowedTypes: { [key: string]: string[] } = {
    script: [".txt", ".docx", ".pdf"],
    face_video: [".mp4", ".mov", ".avi", ".mkv"],
    tv_episode: [".mp4", ".mov", ".avi", ".mkv", ".wmv"],
    audio: [".mp3", ".wav", ".m4a", ".aac"],
  };

  const fileType = req.body.type || req.query.type;
  const ext = path.extname(file.originalname).toLowerCase();

  if (fileType && allowedTypes[fileType]?.includes(ext)) {
    cb(null, true);
  } else {
    cb(new Error(`Invalid file type. Allowed types for ${fileType}: ${allowedTypes[fileType]?.join(", ") || "none"}`));
  }
};

export const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 2 * 1024 * 1024 * 1024, // 2GB limit
  },
});

export function readScriptFile(filePath: string, mimeType: string): Promise<string> {
  return new Promise((resolve, reject) => {
    try {
      if (mimeType === "text/plain" || filePath.endsWith(".txt")) {
        const content = fs.readFileSync(filePath, "utf-8");
        resolve(content);
      } else {
        reject(new Error("Unsupported file type for script reading"));
      }
    } catch (error) {
      reject(error);
    }
  });
}

export function deleteFile(filePath: string): Promise<void> {
  return new Promise((resolve, reject) => {
    fs.unlink(filePath, (err) => {
      if (err) reject(err);
      else resolve();
    });
  });
}

export function getFileStats(filePath: string) {
  const stats = fs.statSync(filePath);
  return {
    size: stats.size,
    created: stats.birthtime,
    modified: stats.mtime,
  };
}
